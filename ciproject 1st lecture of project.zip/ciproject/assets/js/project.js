$(document).ready(function(){
	//console.log(curl)
	$.get(curl+"get_categories",function(data,status){
		//console.log(status)
		if(status=="success"){
			console.log(JSON.parse(data))
		}
	});

	$.get(curl+"get_brands",function(data,status){
		console.log(status)
		if(status=="success"){
			//console.log(JSON.parse(data))
			var str=""
			$.each(JSON.parse(data),function(key,val){
				console.log(val)
				str = str + "<li><a href='#'>"+val.br_name+"</a></li>";
			});
			//console.log(str)
			$(".brands_data").html(str)
		}
	});
});