<?php
defined('BASEPATH') OR exit('no direct script access allowed');

class project extends CI_Controller{
	public function index()
	{
		$this->load->view('index');

	}

	public function get_brands()
	{
		$this->load->model('project_model');
		$ans = $this->project_model->getrecords("brands");
		//print_r($ans);
		if(is_array($ans)){
			echo json_encode($ans);
		}
	}

	public function get_categories()
	{
		$this->load->model('project_model');
		$ans = $this->project_model->getrecords("categories");
		//print_r($ans);
		if(is_array($ans)){
			echo json_encode($ans);
		}
	}



}



?>