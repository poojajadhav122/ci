<?php
 
 class project_model extends CI_Model{
 	function getRecords($tablename){
 		$query = $this->db->get($tablename);
 		//print_r($query);
 		if($query->result_id->num_rows >0){
 			return $query->result();

 		}
 		else{
 			return 0;
 		}
 	}
 }


?>