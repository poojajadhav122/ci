<?php
/**
 * 
 */
class Crud_model extends CI_Model
{
	
	function insertData($ans)
	{
		// echo "test";
		$re = $this->db->insert('users',$ans);
		var_dump($re);
		return $re;
	}
	function selectData(){
		//return "testing";
		$query = $this->db->get('users');
		// echo "<pre>";
		// print_r($query);
		// echo "</pre>";

		if($query->result_id->num_rows >0){
			//echo ok;
			//$ans =$query->result();// this will return our output as a object
			$ans = $query->result_array();//thiswill return our output in array
		// 	echo "<pre>";
		// print_r($ans);
		//  echo "</pre>";
			return $ans;

		}
        else{
        	return 0;
        }
	}
}


?>