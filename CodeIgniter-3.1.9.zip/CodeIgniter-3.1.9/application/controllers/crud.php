<?php
  /**
   * 
   */
  class Crud extends CI_Controller
  {
  	public function index(){
        echo "<pre>";
        print_r($this);
        echo "</pre>";
  		$this->load->view('index');
  	}

  	public function show(){
  		//echo "test";
  		$this->load->model('crud_model');
  		$result= $this->crud_model->selectData();
  		// echo "<pre>";
  		// print_r($result);
  		// echo "</pre>";
  		$this->load->view('show_view',array("xyz"=>$result)); //here we did that we call the page also the page name is show_view then we want in array data so we given key from this "xyz" key we pass the data


  	}
  	public function action_page(){
  		// print_r($_POST);
  		// $this->load->library('form_validation');
  		 $this->form_validation->set_rules('uemail','EMAILID','trim|required|valid_email|is_unique[users.uemail]');
  		$this->form_validation->set_rules('upass','PASSWORD','trim|required|min_length[4]|max_length[12]|alpha_numeric');

  		if($this->form_validation->run() == false){
  			//echo error;
  			$this->load->view('index');
  		}
  		else{
  			//echo "ok";
  			$_POST['upass'] = do_hash($_POST['upass']);
  			//print_r($_POST);
  			 $this->load->model('crud_model');//here this is crud_model is page then it at down line-->
  			if($this->crud_model->insertData($_POST)){ //here this crud_model become object then insertdata is the function which we call at application/model/Crud_model.php this page and this $_POST we taken as object and in the page of Crud_model we call as($ans)
  				echo "Record Added";
  			}


  		}
  		
  	}

}
?>